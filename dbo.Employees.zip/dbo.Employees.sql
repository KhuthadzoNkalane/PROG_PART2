﻿CREATE TABLE [dbo].[Employees] (
    [EmployeeID]  INT           NOT NULL,
    [FirstName]   VARCHAR (255) NOT NULL,
    [LastName]    VARCHAR (255) NOT NULL,
    [Email]       VARCHAR (255) NOT NULL,
    [AddressLine] VARCHAR (255) NOT NULL,
    [City]        VARCHAR (255) NOT NULL
);

